INSERT INTO public.users (id, name, mobile, latitude, longitude, created_at, updated_at)
VALUES (2, 'John Doe', '1234567890', 37.1234, -122.5678, NOW(), NOW());